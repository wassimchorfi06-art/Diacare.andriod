# 🚀 دليل رفع DiaCare على GitHub + GitHub Actions

## هيكل المشروع على GitHub

```
diacare-android/
├── .github/
│   └── workflows/
│       └── android-ci.yml   ← ملف الـ CI/CD (موجود هنا)
├── www/
│   ├── index.html
│   └── icon.png
├── android-project/
│   ├── app/
│   │   ├── build.gradle
│   │   └── src/...
│   ├── build.gradle
│   └── settings.gradle
├── capacitor.config.json
├── package.json
├── .gitignore
└── README.md
```

---

## 📋 الخطوة 1 — إنشاء Repository على GitHub

1. افتح [github.com/new](https://github.com/new)
2. اختر:
   - **Repository name:** `diacare-android`
   - **Visibility:** Private (مستحسن) أو Public
   - **لا تضف** README أو .gitignore (موجودين محلياً)
3. اضغط **Create repository**

---

## 💻 الخطوة 2 — رفع المشروع من جهازك

افتح Terminal داخل مجلد `diacare-android/`:

```bash
# تهيئة Git
git init

# إضافة كل الملفات
git add .

# أول commit
git commit -m "🎉 Initial commit - DiaCare v1.0.0"

# ربط بـ GitHub (استبدل USERNAME باسم حسابك)
git remote add origin https://github.com/USERNAME/diacare-android.git

# رفع على الـ main branch
git push -u origin main
```

---

## 🔐 الخطوة 3 — إعداد GitHub Secrets (للـ Release)

هذه الـ Secrets تحفظ مفتاح التوقيع بأمان بدون ما ترفعه للـ repo.

### أولاً: أنشئ Keystore (مرة واحدة فقط)

```bash
keytool -genkey -v \
  -keystore diacare-release.jks \
  -keyalg RSA -keysize 2048 \
  -validity 10000 \
  -alias diacare-key
```
> سيطلب منك اسم، منظمة، كلمة سر — احفظها جيداً!

### ثانياً: حوّل الـ Keystore إلى Base64

```bash
# على Mac/Linux
base64 -i diacare-release.jks | tr -d '\n'

# على Windows (PowerShell)
[Convert]::ToBase64String([IO.File]::ReadAllBytes("diacare-release.jks"))
```
انسخ النتيجة كاملة.

### ثالثاً: أضف الـ Secrets في GitHub

اذهب لـ: `GitHub Repo → Settings → Secrets and variables → Actions → New repository secret`

أضف هذه الـ 4 Secrets:

| Secret Name | القيمة |
|---|---|
| `KEYSTORE_BASE64` | النص الـ base64 من الخطوة السابقة |
| `KEY_ALIAS` | `diacare-key` (أو ما اخترته) |
| `KEY_PASSWORD` | كلمة سر الـ key |
| `STORE_PASSWORD` | كلمة سر الـ keystore |

---

## 🔄 الخطوة 4 — كيف يعمل الـ CI/CD

### على كل `push` إلى main أو develop:
```
push → GitHub Actions يشغّل Job تلقائياً
     → يثبت Node.js + JDK 17
     → npm install + cap sync android
     → يبني Debug APK
     → يحفظه كـ artifact (7 أيام)
```

### لرفع إصدار جديد (Release):
```bash
# Tag الإصدار الجديد
git tag v1.1.0
git push origin v1.1.0
```
```
tag → يبني Release APK + AAB موقّعَين
    → ينشئ GitHub Release تلقائياً
    → يرفع الـ APK و AAB كـ attachments
```

---

## 📱 الخطوة 5 — رؤية نتائج البناء

1. اذهب لـ GitHub Repo
2. اضغط على تبويب **Actions**
3. ستجد كل الـ workflows تعمل تلقائياً
4. اضغط على أي workflow لترى التفاصيل والـ logs
5. لتحميل الـ APK: اضغط على الـ workflow → **Artifacts** → حمّل

---

## 🏷️ الخطوة 6 — سير عمل التطوير اليومي

```bash
# 1. عدّل index.html أو أي ملف
# 2. احفظ التغييرات
git add .
git commit -m "✨ feat: وصف التغيير"
git push origin main
# ← GitHub Actions سيبني Debug APK تلقائياً ✅

# لإصدار نسخة جديدة للمستخدمين:
git tag v1.2.0
git push origin v1.2.0
# ← GitHub Actions سيبني Release + ينشئ GitHub Release ✅
```

---

## 🐛 حل مشاكل شائعة

| المشكلة | الحل |
|---|---|
| `Gradle build failed` | تحقق من الـ logs في Actions tab |
| `Keystore not found` | تأكد من إضافة KEYSTORE_BASE64 في Secrets |
| `npm ci failed` | تأكد من وجود `package-lock.json` في الـ repo |
| الـ APK لا يُوجد في Artifacts | الـ Debug APK يُحفظ 7 أيام فقط |
| `cap sync: command not found` | تأكد أن `@capacitor/cli` في devDependencies |

---

## 📊 ملخص الـ Workflows

| الحدث | الـ Job | النتيجة |
|---|---|---|
| push إلى main/develop | build-debug | Debug APK (artifact) |
| pull request | build-debug | Debug APK (للمراجعة) |
| tag v*.*.* | build-release | Release APK + AAB + GitHub Release |
