# 📱 DiaCare - دليل تحويل HTML إلى تطبيق أندرويد

## هيكل المشروع

```
diacare-android/
├── www/                          ← ملفات التطبيق (HTML/CSS/JS)
│   ├── index.html                ← تطبيقك الرئيسي
│   └── icon.png                  ← أيقونة PWA
├── android-project/              ← مشروع Android الجاهز
│   ├── app/
│   │   ├── build.gradle          ← إعدادات البناء
│   │   └── src/main/
│   │       ├── AndroidManifest.xml
│   │       ├── java/com/diacare/app/
│   │       │   └── MainActivity.kt
│   │       ├── assets/www/       ← انسخ محتوى www/ هنا
│   │       └── res/
│   │           ├── mipmap-*/     ← الأيقونات (جاهزة ✅)
│   │           ├── values/styles.xml
│   │           └── drawable/
│   ├── build.gradle
│   └── settings.gradle
├── capacitor.config.json         ← إعدادات Capacitor
├── package.json
└── README.md                     ← هذا الملف
```

---

## 🚀 خطوات التثبيت

### المتطلبات أولاً
تأكد من تثبيت:
- **[Node.js](https://nodejs.org)** (v18 أو أحدث)
- **[Android Studio](https://developer.android.com/studio)** (أحدث إصدار)
- **Java JDK 17** (يأتي مع Android Studio)

---

### الخطوة 1: تثبيت Node.js والأدوات

```bash
# تحقق من تثبيت Node.js
node --version   # يجب أن يظهر v18 أو أحدث
npm --version
```

---

### الخطوة 2: افتح Terminal داخل مجلد المشروع

```bash
cd diacare-android
```

---

### الخطوة 3: تثبيت الحزم

```bash
npm install
```

---

### الخطوة 4: إضافة منصة Android

```bash
npx cap add android
```

> سيقوم هذا بإنشاء مجلد `android/` تلقائياً بالإعدادات الصحيحة.

---

### الخطوة 5: مزامنة ملفات التطبيق

```bash
npx cap sync android
```

> ينسخ محتوى `www/` داخل مشروع Android ويثبت الـ plugins.

---

### الخطوة 6: فتح المشروع في Android Studio

```bash
npx cap open android
```

> سيفتح Android Studio تلقائياً مع المشروع الجاهز.

---

### الخطوة 7: تشغيل التطبيق

في Android Studio:
1. انتظر حتى ينتهي **Gradle Sync** (قد يأخذ دقائق أول مرة)
2. اختر جهازك أو **Emulator** من القائمة العلوية
3. اضغط زر **▶ Run** (أو `Shift + F10`)

---

## 🎨 الأيقونات

الأيقونات جاهزة في المجلدات:
```
res/mipmap-mdpi/ic_launcher.png        (48×48)
res/mipmap-hdpi/ic_launcher.png        (72×72)
res/mipmap-xhdpi/ic_launcher.png       (96×96)
res/mipmap-xxhdpi/ic_launcher.png      (144×144)
res/mipmap-xxxhdpi/ic_launcher.png     (192×192)
```
كل حجم يأتي بنسختين: **مربعة مستديرة الأركان** و**دائرية**.

---

## 📦 بناء APK للنشر

### APK للاختبار (Debug)
```bash
# في Android Studio: Build → Build Bundle(s)/APK(s) → Build APK(s)
# أو عبر Terminal:
cd android
./gradlew assembleDebug
# النتيجة في: android/app/build/outputs/apk/debug/app-debug.apk
```

### APK للنشر على Google Play (Release)
```bash
# أولاً أنشئ Signing Key:
keytool -genkey -v -keystore diacare-key.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias diacare

# ثم في Android Studio:
# Build → Generate Signed Bundle/APK → APK → أدخل بيانات الـ key
```

---

## ⚙️ تخصيصات إضافية

### تغيير اسم التطبيق
في `app/src/main/res/values/strings.xml`:
```xml
<string name="app_name">DiaCare</string>
```

### تغيير الأيقونة لاحقاً
في Android Studio:
- Click right على `res` → **New** → **Image Asset**
- اختر **Launcher Icons (Adaptive and Legacy)**
- ارفع الصورة الجديدة

### إضافة Splash Screen مخصص
في `capacitor.config.json` قسم `SplashScreen` يمكن تعديل:
- `launchShowDuration`: مدة الظهور بالميلي ثانية
- `backgroundColor`: لون الخلفية

---

## 🔔 الإشعارات

التطبيق يدعم **Local Notifications** عبر:
- `@capacitor/local-notifications`
- تم إضافة الأذونات في `AndroidManifest.xml`

---

## 🐛 حل المشاكل الشائعة

| المشكلة | الحل |
|---------|------|
| `Gradle sync failed` | تأكد من اتصال الإنترنت وأن JDK 17 مثبت |
| `SDK not found` | افتح Android Studio → SDK Manager → ثبّت Android 14 (API 34) |
| `Emulator slow` | فعّل **Hardware Acceleration (HAXM)** في BIOS |
| الخطوط العربية لا تظهر | تأكد من وجود اتصال إنترنت (الخطوط من Google Fonts) |
| `Permission denied` | على Linux/Mac: `chmod +x android/gradlew` |

---

## 📋 معلومات التطبيق

| الخاصية | القيمة |
|---------|--------|
| App ID | `com.diacare.app` |
| الإصدار | `1.0.0` |
| Min Android | Android 7.0 (API 24) |
| Target Android | Android 14 (API 34) |
| الإطار | Capacitor 5 |
| اللغة | Kotlin |

---

## 📞 الخطوة التالية: النشر على Google Play

1. أنشئ حساب **Google Play Console**: https://play.google.com/console
2. ادفع رسوم التسجيل (25 دولار مرة واحدة)
3. ارفع ملف **AAB** (Android App Bundle):
   ```bash
   ./gradlew bundleRelease
   ```
4. أضف الوصف، الصور، وتصنيف المحتوى
5. انشر! 🚀
